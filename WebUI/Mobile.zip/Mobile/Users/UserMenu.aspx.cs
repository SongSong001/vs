﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WC.WebUI.Mobile.Users
{
    public partial class UserMenu : WC.BLL.MobilePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}