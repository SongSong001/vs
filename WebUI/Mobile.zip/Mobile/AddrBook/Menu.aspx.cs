﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WC.WebUI.Mobile.AddrBook
{
    public partial class Menu : WC.BLL.MobilePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}